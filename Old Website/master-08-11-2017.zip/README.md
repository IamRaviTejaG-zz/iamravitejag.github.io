# iamravitejag.github.io

<!--**Needs ~~good number of~~ few fixes!**-->

<!--_Here are the known problems:_-->

<!--~~1. The images do not scale as expected on mobile devices. Infact, they do not even show up on my phone with 5.5" FHD display.~~-->
<!--1. This has been fixed. The images now scale comfortably at all resolutions.-->

<!--2. The footer (the copyright text) does not show up on the bottom right side on all resolutions. This has something to do with the **br** tags mostly. Need to find an alternative for vertical spacing instead of using **br** tags.-->

_Now, with Bootstrap & jQuery!_
